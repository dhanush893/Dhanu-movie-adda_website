// Dhanu Movie Adda — "My List" persistence (localStorage, per-browser)

const WATCHLIST_KEY = "dma_my_list";

const Watchlist = {
  getAll() {
    try {
      const raw = localStorage.getItem(WATCHLIST_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  },

  has(id) {
    return this.getAll().some((m) => m.id === id);
  },

  add(movie) {
    const list = this.getAll();
    if (list.some((m) => m.id === movie.id)) return;
    list.unshift({
      id: movie.id,
      title: movie.title,
      poster_path: movie.poster_path,
      release_date: movie.release_date,
      vote_average: movie.vote_average,
    });
    localStorage.setItem(WATCHLIST_KEY, JSON.stringify(list));
  },

  remove(id) {
    const list = this.getAll().filter((m) => m.id !== id);
    localStorage.setItem(WATCHLIST_KEY, JSON.stringify(list));
  },

  // Returns true if the movie is now in the list, false if it was removed.
  toggle(movie) {
    if (this.has(movie.id)) {
      this.remove(movie.id);
      return false;
    }
    this.add(movie);
    return true;
  },
};
