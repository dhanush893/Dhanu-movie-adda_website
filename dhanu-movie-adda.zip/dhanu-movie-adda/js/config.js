// Dhanu Movie Adda — configuration
//
// Get a free TMDB API key (v3 auth) at:
//   https://www.themoviedb.org/settings/api
// then paste it below. Without a key the site still runs, but shows
// an onboarding message instead of real movie data.

const TMDB_API_KEY = "YOUR_TMDB_API_KEY_HERE";

const TMDB_BASE = "https://api.themoviedb.org/3";
const TMDB_IMG_BASE = "https://image.tmdb.org/t/p/";
