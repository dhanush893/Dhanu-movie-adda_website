// Dhanu Movie Adda — TMDB API wrapper
// Docs: https://developer.themoviedb.org/reference/intro/getting-started

async function tmdbFetch(path, params = {}) {
  if (!TMDB_API_KEY || TMDB_API_KEY === "YOUR_TMDB_API_KEY_HERE") {
    const err = new Error("Missing TMDB API key");
    err.code = "NO_API_KEY";
    throw err;
  }
  const url = new URL(TMDB_BASE + path);
  url.searchParams.set("api_key", TMDB_API_KEY);
  Object.entries(params).forEach(([key, value]) => url.searchParams.set(key, value));

  let res;
  try {
    res = await fetch(url);
  } catch {
    const err = new Error("Network request to TMDB failed");
    err.code = "NETWORK_ERROR";
    throw err;
  }
  if (!res.ok) {
    const err = new Error(`TMDB request failed (${res.status})`);
    err.code = "REQUEST_FAILED";
    throw err;
  }
  return res.json();
}

const Api = {
  trending: () => tmdbFetch("/trending/movie/week"),
  popular: () => tmdbFetch("/movie/popular"),
  topRated: () => tmdbFetch("/movie/top_rated"),
  search: (query, page = 1) => tmdbFetch("/search/movie", { query, page, include_adult: false }),
  detail: (id) => tmdbFetch(`/movie/${id}`, { append_to_response: "credits,videos" }),
  imageUrl: (path, size = "w500") => (path ? `${TMDB_IMG_BASE}${size}${path}` : null),
};
