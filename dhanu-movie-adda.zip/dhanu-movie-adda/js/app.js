// Dhanu Movie Adda — routing, rendering, interactions

const detailCache = new Map();
let homeLoaded = false;

/* ---------- small helpers ---------- */

function escapeHtml(str = "") {
  return String(str).replace(/[&<>"']/g, (c) => (
    { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]
  ));
}

function truncate(str = "", n) {
  return str.length > n ? str.slice(0, n).trim() + "…" : str;
}

function yearOf(dateStr) {
  return dateStr ? dateStr.slice(0, 4) : "—";
}

function ratingOf(value) {
  return typeof value === "number" ? value.toFixed(1) : "–";
}

function emptyStateHtml(message, ctaHtml = "") {
  return `<div class="empty-state"><p>${escapeHtml(message)}</p>${ctaHtml}</div>`;
}

function errorStateHtml(err) {
  if (err && err.code === "NO_API_KEY") {
    return emptyStateHtml(
      "Add your TMDB API key in js/config.js to load movies.",
      `<a class="btn btn-outline" href="https://www.themoviedb.org/settings/api" target="_blank" rel="noopener">Get a free key</a>`
    );
  }
  return emptyStateHtml("Something went wrong loading this. Please try again in a moment.");
}

/* ---------- card + rail rendering ---------- */

function movieCard(movie) {
  const poster = Api.imageUrl(movie.poster_path, "w342");
  return `
    <a href="#detail-${movie.id}" class="card" data-id="${movie.id}">
      <div class="card-poster" style="${poster ? `background-image:url('${poster}')` : ""}">
        ${!poster ? `<span class="card-fallback">${escapeHtml(movie.title)}</span>` : ""}
        <span class="card-rating">★ ${ratingOf(movie.vote_average)}</span>
      </div>
      <p class="card-title">${escapeHtml(movie.title)}</p>
      <p class="card-year">${yearOf(movie.release_date)}</p>
    </a>
  `;
}

function renderRail(container, title, movies) {
  if (!movies || !movies.length) return;
  const rail = document.createElement("section");
  rail.className = "rail";
  rail.innerHTML = `
    <div class="rail-head"><h2>${escapeHtml(title)}</h2></div>
    <div class="rail-track">${movies.map(movieCard).join("")}</div>
  `;
  container.appendChild(rail);
}

/* ---------- hero ---------- */

function renderHero(movie) {
  const hero = document.getElementById("hero");
  const backdrop = Api.imageUrl(movie.backdrop_path, "original");
  hero.innerHTML = `
    <div class="hero-backdrop" style="${backdrop ? `background-image:url('${backdrop}')` : ""}"></div>
    <div class="hero-scrim"></div>
    <div class="hero-content">
      <h1>${escapeHtml(movie.title)}</h1>
      <div class="hero-meta">
        <span class="chip chip-rating">★ ${ratingOf(movie.vote_average)}</span>
        <span class="chip">${yearOf(movie.release_date)}</span>
      </div>
      <p class="hero-overview">${escapeHtml(truncate(movie.overview || "", 170))}</p>
      <div class="hero-actions">
        <button class="btn btn-primary" id="hero-trailer">▶ Watch trailer</button>
        <a class="btn btn-outline" href="#detail-${movie.id}">More info</a>
      </div>
    </div>
  `;
  document.getElementById("hero-trailer").addEventListener("click", () => openTrailerFor(movie.id));
}

function renderOnboardingHero() {
  const hero = document.getElementById("hero");
  hero.innerHTML = `
    <div class="hero-backdrop hero-backdrop--empty"></div>
    <div class="hero-scrim"></div>
    <div class="hero-content">
      <h1>Welcome to Dhanu Movie Adda</h1>
      <p class="hero-overview">Add a free TMDB API key in <code>js/config.js</code> to bring in real posters, ratings and trailers.</p>
      <div class="hero-actions">
        <a class="btn btn-primary" href="https://www.themoviedb.org/settings/api" target="_blank" rel="noopener">Get a free API key</a>
      </div>
    </div>
  `;
}

function renderHeroError() {
  const hero = document.getElementById("hero");
  hero.innerHTML = `
    <div class="hero-backdrop hero-backdrop--empty"></div>
    <div class="hero-scrim"></div>
    <div class="hero-content">
      <h1>Couldn't reach TMDB</h1>
      <p class="hero-overview">Check your connection and reload the page.</p>
    </div>
  `;
}

/* ---------- views: home / search / my list / detail ---------- */

async function loadHome() {
  if (homeLoaded) return;
  const railsEl = document.getElementById("home-rails");
  try {
    const trending = await Api.trending();
    const [popular, topRated] = await Promise.all([Api.popular(), Api.topRated()]);

    if (!trending.results || !trending.results.length) throw new Error("empty");
    renderHero(trending.results[0]);

    railsEl.innerHTML = "";
    renderRail(railsEl, "Trending this week", trending.results.slice(1, 13));
    renderRail(railsEl, "Popular right now", popular.results.slice(0, 12));
    renderRail(railsEl, "Critically acclaimed", topRated.results.slice(0, 12));
    homeLoaded = true;
  } catch (err) {
    if (err && err.code === "NO_API_KEY") {
      renderOnboardingHero();
    } else {
      renderHeroError();
    }
  }
}

function wireSearch() {
  const input = document.getElementById("search-input");
  const results = document.getElementById("search-results");
  let debounce;

  input.addEventListener("input", () => {
    clearTimeout(debounce);
    const query = input.value.trim();
    if (!query) {
      results.innerHTML = emptyStateHtml("Search for a movie to get started.");
      return;
    }
    debounce = setTimeout(async () => {
      results.innerHTML = `<p class="loading">Searching…</p>`;
      try {
        const data = await Api.search(query);
        results.innerHTML = data.results && data.results.length
          ? data.results.map(movieCard).join("")
          : emptyStateHtml(`No results for "${query}".`);
      } catch (err) {
        results.innerHTML = errorStateHtml(err);
      }
    }, 350);
  });
}

function renderMyList() {
  const grid = document.getElementById("mylist-grid");
  const list = Watchlist.getAll();
  if (!list.length) {
    grid.innerHTML = emptyStateHtml('Your list is empty. Find something and tap "Add to my list" to save it here.');
    return;
  }
  grid.innerHTML = list.map((movie) => {
    const poster = Api.imageUrl(movie.poster_path, "w342");
    return `
      <div class="card list-card" data-id="${movie.id}">
        <a href="#detail-${movie.id}" class="card-poster" style="${poster ? `background-image:url('${poster}')` : ""}">
          ${!poster ? `<span class="card-fallback">${escapeHtml(movie.title)}</span>` : ""}
        </a>
        <button class="card-remove" type="button" aria-label="Remove ${escapeHtml(movie.title)} from my list" data-remove="${movie.id}">×</button>
        <p class="card-title">${escapeHtml(movie.title)}</p>
        <p class="card-year">${yearOf(movie.release_date)}</p>
      </div>
    `;
  }).join("");

  grid.querySelectorAll("[data-remove]").forEach((btn) => {
    btn.addEventListener("click", () => {
      Watchlist.remove(Number(btn.dataset.remove));
      renderMyList();
    });
  });
}

async function getDetailCached(id) {
  if (detailCache.has(id)) return detailCache.get(id);
  const data = await Api.detail(id);
  detailCache.set(id, data);
  return data;
}

async function loadDetail(id) {
  const el = document.getElementById("detail-content");
  el.innerHTML = `<p class="loading">Loading…</p>`;
  try {
    const movie = await getDetailCached(id);
    const backdrop = Api.imageUrl(movie.backdrop_path, "original");
    const poster = Api.imageUrl(movie.poster_path, "w342");
    const cast = (movie.credits && movie.credits.cast || []).slice(0, 6).map((c) => c.name).join(", ");
    const inList = Watchlist.has(movie.id);

    el.innerHTML = `
      <div class="detail-backdrop" style="${backdrop ? `background-image:url('${backdrop}')` : ""}"></div>
      <div class="detail-scrim"></div>
      <a href="#home" class="detail-back" aria-label="Back to home">←</a>
      <div class="detail-body">
        ${poster ? `<img class="detail-poster" src="${poster}" alt="${escapeHtml(movie.title)} poster">` : "<div></div>"}
        <div class="detail-info">
          <h1>${escapeHtml(movie.title)}</h1>
          ${movie.tagline ? `<p class="detail-tagline">${escapeHtml(movie.tagline)}</p>` : ""}
          <div class="chip-row">
            <span class="chip chip-rating">★ ${ratingOf(movie.vote_average)}</span>
            <span class="chip">${yearOf(movie.release_date)}</span>
            ${movie.runtime ? `<span class="chip">${movie.runtime} min</span>` : ""}
            ${(movie.genres || []).map((g) => `<span class="chip">${escapeHtml(g.name)}</span>`).join("")}
          </div>
          <p class="detail-overview">${escapeHtml(movie.overview || "No synopsis available.")}</p>
          ${cast ? `<p class="detail-cast"><span>Starring</span>${escapeHtml(cast)}</p>` : ""}
          <div class="detail-actions">
            <button class="btn btn-primary" id="detail-trailer">▶ Watch trailer</button>
            <button class="btn ${inList ? "btn-active" : "btn-outline"}" id="detail-list-toggle">
              ${inList ? "✓ In my list" : "+ Add to my list"}
            </button>
          </div>
        </div>
      </div>
    `;

    document.getElementById("detail-trailer").addEventListener("click", () => openTrailerFor(movie.id));
    document.getElementById("detail-list-toggle").addEventListener("click", (e) => {
      const btn = e.currentTarget;
      const nowIn = Watchlist.toggle(movie);
      btn.textContent = nowIn ? "✓ In my list" : "+ Add to my list";
      btn.classList.toggle("btn-active", nowIn);
      btn.classList.toggle("btn-outline", !nowIn);
    });
  } catch (err) {
    el.innerHTML = `<div class="detail-body" style="padding-top:8rem;grid-template-columns:1fr">${errorStateHtml(err)}</div>`;
  }
}

/* ---------- trailer modal ---------- */

async function openTrailerFor(id) {
  const modal = document.getElementById("trailer-modal");
  const frame = document.getElementById("trailer-frame");
  try {
    const movie = await getDetailCached(id);
    const vids = (movie.videos && movie.videos.results) || [];
    const trailer =
      vids.find((v) => v.site === "YouTube" && v.type === "Trailer") ||
      vids.find((v) => v.site === "YouTube");
    if (!trailer) {
      alert("No trailer is available for this title yet.");
      return;
    }
    frame.src = `https://www.youtube.com/embed/${trailer.key}?autoplay=1&rel=0`;
    modal.hidden = false;
  } catch {
    alert("Couldn't load the trailer right now.");
  }
}

function closeTrailer() {
  const modal = document.getElementById("trailer-modal");
  const frame = document.getElementById("trailer-frame");
  frame.src = "";
  modal.hidden = true;
}

/* ---------- router ---------- */

const ROUTE_VIEWS = {
  "#home": "view-home",
  "#search": "view-search",
  "#mylist": "view-mylist",
};

function route() {
  const hash = location.hash || "#home";

  document.querySelectorAll(".view").forEach((v) => (v.hidden = true));
  document.querySelectorAll(".nav-link").forEach((a) => a.classList.remove("active"));

  if (hash.startsWith("#detail-")) {
    document.getElementById("view-detail").hidden = false;
    loadDetail(hash.replace("#detail-", ""));
    window.scrollTo(0, 0);
    return;
  }

  const viewId = ROUTE_VIEWS[hash] || "view-home";
  document.getElementById(viewId).hidden = false;
  document.querySelectorAll(`.nav-link[data-route="${viewId}"]`).forEach((a) => a.classList.add("active"));
  window.scrollTo(0, 0);

  if (viewId === "view-home") loadHome();
  if (viewId === "view-mylist") renderMyList();
  if (viewId === "view-search") {
    const input = document.getElementById("search-input");
    if (input && window.innerWidth >= 900) input.focus();
  }
}

/* ---------- init ---------- */

window.addEventListener("hashchange", route);

document.addEventListener("DOMContentLoaded", () => {
  route();
  wireSearch();

  document.querySelectorAll("[data-close-modal]").forEach((el) => {
    el.addEventListener("click", closeTrailer);
  });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") closeTrailer();
  });
});
